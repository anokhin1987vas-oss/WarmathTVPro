package com.warmath.tvpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 19, 16)
    private val panel = Color.rgb(27, 34, 29)
    private val green = Color.rgb(0, 220, 105)
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var urlInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(24))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(text("WARMATH", 30f, green, true))
        page.addView(text("TV PRO  •  FOOTBALL HUB", 13f, Color.LTGRAY, true))
        page.addView(space(18))
        page.addView(text("Матчи и видео", 22f, Color.WHITE, true))
        page.addView(text("Добавляй ссылку на разрешённую трансляцию ниже. Встроенных пиратских потоков нет.", 14f, Color.LTGRAY, false))
        page.addView(space(14))

        val matchCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(panel)
        }
        matchCard.addView(text("⚽  LIVE / ВИДЕО", 14f, green, true))
        matchCard.addView(space(6))
        matchCard.addView(text("Твой футбольный экран", 19f, Color.WHITE, true))
        matchCard.addView(text("Список матчей можно подключить к легальному API в следующем этапе.", 13f, Color.LTGRAY, false))
        page.addView(matchCard, matchParams())

        page.addView(space(18))
        page.addView(text("Видеоплеер", 20f, Color.WHITE, true))
        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
        }
        page.addView(playerView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
        ))
        page.addView(space(10))

        urlInput = EditText(this).apply {
            hint = "Вставь HTTPS-ссылку на видео (MP4 / HLS .m3u8)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
        }
        page.addView(urlInput, LinearLayout.LayoutParams(-1, dp(52)))
        page.addView(space(8))

        val play = Button(this).apply {
            text = "▶  ОТКРЫТЬ ТРАНСЛЯЦИЮ"
            setTextColor(Color.BLACK)
            setBackgroundColor(green)
            setOnClickListener { playUrl() }
        }
        page.addView(play, LinearLayout.LayoutParams(-1, dp(52)))
        page.addView(space(8))
        status = text("Готово к воспроизведению", 13f, Color.LTGRAY, false)
        page.addView(status)
        page.addView(space(18))
        page.addView(text("PRO-функции", 20f, Color.WHITE, true))
        listOf("✓  Тёмный интерфейс", "✓  Встроенный видеоплеер", "✓  Поддержка MP4 и HLS", "✓  Без встроенных рекламных SDK", "•  Избранное и телепрограмма — следующий этап").forEach {
            page.addView(space(5))
            page.addView(text(it, 15f, if (it.startsWith("✓")) green else Color.LTGRAY, false))
        }
    }

    private fun playUrl() {
        val url = urlInput.text.toString().trim()
        if (!(url.startsWith("https://"))) {
            status.text = "Нужна корректная HTTPS-ссылка на видео."
            return
        }
        try {
            player?.release()
            player = ExoPlayer.Builder(this).build().also { exo ->
                playerView.player = exo
                exo.setMediaItem(MediaItem.fromUri(url))
                exo.prepare()
                exo.playWhenReady = true
                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        status.text = when (playbackState) {
                            Player.STATE_BUFFERING -> "Загрузка видео…"
                            Player.STATE_READY -> "Видео готово"
                            Player.STATE_ENDED -> "Видео завершено"
                            else -> "Плеер запущен"
                        }
                    }
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        status.text = "Не удалось открыть поток. Проверь ссылку и доступность источника."
                    }
                })
            }
        } catch (_: Exception) {
            status.text = "Ошибка запуска плеера. Проверь ссылку."
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.START
        }

    private fun space(dp: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(dp))
    }

    private fun matchParams() = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(10)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
